#!/bin/bash

echo "
          Zedthon

        𓍹 Visit @Zedthon for help 𓍻
"

python3 -m userbot
